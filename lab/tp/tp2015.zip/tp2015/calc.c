#include <stdio.h>
#include <ctype.h> 

#define MAXTOKEN 100
#define NUMBER '0'

struct node {
  int v;
  struct node *next;
};

struct node *head = NULL;

void push(int i) {
  // Insertar en la lista representada por 'head' un nodo por delante.
}

int pop() {
  // remover en la lista representada por 'head' un nodo por delante.
}

int get_token(char buffer[]) {
  // Leer el próximo token de la entrada estándar.
}

int main() {
  int type;
  int n;

  char buffer[MAXTOKEN];

  while((type = get_token(buffer)) != EOF) {
    switch(type) {
    case NUMBER:
      n = atoi(buffer); // convierte de cadena a entero
      // completar
      break;
    case '+':
      //completar
      break;
    case '-':
      //completar
      break;
    case '*':
      //completar
      break;
    case '/':
      //completar
      break;
    default:
      printf("error: comando desconocido %s\n", buffer);
      break;
    }
  }

  return 0;

}
